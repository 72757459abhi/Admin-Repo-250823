import React  from "react";


const ActionBtn=(props)=>{
    return(<>
    <button type="submit" >Update Amount</button>
    </>)
}
export default ActionBtn